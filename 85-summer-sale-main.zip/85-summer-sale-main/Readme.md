# summer-sale

## [ Private Repo Link](https://classroom.github.com/a/uicCJkDQ)

Click here for the private repo: [https://classroom.github.com/a/uicCJkDQ](https://classroom.github.com/a/uicCJkDQ)
